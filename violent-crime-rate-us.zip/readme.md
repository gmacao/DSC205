# Estimated violent crime rate in the United States - Data package

This data package contains the data that powers the chart ["Estimated violent crime rate in the United States"](https://ourworldindata.org/grapher/violent-crime-rate-us?v=1&csvType=full&useColumnShortNames=false&utm_source=chatgpt.com) on the Our World in Data website. It was downloaded on November 10, 2026.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV structure

Each row is an observation for an entity (usually a country or region) at a timepoint.

- "Entity" — the name of the entity, e.g. "United States".
- "Code" — our internal entity code. For most countries this is the [ISO alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code, e.g. "USA"; historical and other non-standard entities get a custom code.
- "Year" or "Day" — the timepoint. Annual data has a "Year" column holding an integer year; otherwise a "Day" column holds a date string in the form "YYYY-MM-DD".
- The final column is the data column — the time series that powers the chart. Downloaded with the "full data" option it corresponds to the time series below; with "only selected data visible in the chart" it is transformed depending on the chart type, so the correspondence may be less direct.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc.

## How we process data at Our World in Data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stitch together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

Preparing this data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/).

## Detailed information about the data


### Estimated violent crime rate per 100,000 population
Violent crime is composed of four offenses: murder and nonnegligent manslaughter, rape, robbery, and aggravated assault.
Last updated: November 21, 2025  
Next expected update: November 2026  
Date range: 1979–2024  
Unit: violent crimes per 100,000 population  
Source: FBI (2025) – processed by Our World in Data  

#### How to cite this data

FBI (2025) – processed by Our World in Data

#### What you should know about this data
This data reflects the hierarchy rule, which requires that only the most serious offense in a case be counted. The descending order of violent crimes are homicide, rape, robbery, and aggravated assault, followed by the property crimes of burglary, larceny-theft, and motor vehicle theft. For example, if a robbery occurs during which a homicide takes place, only the homicide is counted.


## Sources

These are the sources behind the data in this package. Each time series above names the ones it draws on in its citation.

### FBI – Summary Reporting System (SRS) Estimates

This dataset contains estimated data at the state and national level and was derived from the Summary Reporting System (SRS). These data reflect the estimates the FBI has traditionally included in its annual publications. Download this dataset to see the FBI's estimated crime totals for the nation and all 50 states, 1979 to current year available.

Producer: FBI  
Published: 2025-08-05  
Retrieved on: 2025-11-21  
Retrieved from: https://cde.ucr.cjis.gov/LATEST/webapp/#/pages/downloads  
License: U.S. Public Domain  

Citation: Federal Bureau of Investigation (2025). Estimated crime totals for the nation and all 50 states, 1979–2024. Summary Reporting System (SRS) Estimates.

    